function preload() {
    img = loadImage('https://images.pexels.com/photos/128756/pexels-photo-128756.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500');

}
function setup() {
  createCanvas(400, 400);
}

function draw() {
  image(img, 10, 10 ,150 ,120);
  
  fill(0, 128, 0);
  stroke(0, 128, 0);
  circle(350, 50, 70);

}